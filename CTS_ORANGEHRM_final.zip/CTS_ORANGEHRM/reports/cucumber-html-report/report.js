$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("anil.feature");
formatter.feature({
  "line": 2,
  "name": "orangehrm website",
  "description": "",
  "id": "orangehrm-website",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@orangeHRM"
    }
  ]
});
formatter.scenarioOutline({
  "line": 5,
  "name": "validate the login",
  "description": "",
  "id": "orangehrm-website;validate-the-login",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 4,
      "name": "@tc_00_login"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "I launched the browser",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "I enters the \"\u003cemail\u003e\" and \"\u003cpass\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I click login",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I am on the homePage",
  "keyword": "Then "
});
formatter.examples({
  "line": 11,
  "name": "",
  "description": "",
  "id": "orangehrm-website;validate-the-login;",
  "rows": [
    {
      "cells": [
        "email",
        "pass"
      ],
      "line": 12,
      "id": "orangehrm-website;validate-the-login;;1"
    },
    {
      "cells": [
        "Admin",
        "admin123"
      ],
      "line": 13,
      "id": "orangehrm-website;validate-the-login;;2"
    },
    {
      "cells": [
        "admin",
        "Admin124"
      ],
      "line": 14,
      "id": "orangehrm-website;validate-the-login;;3"
    },
    {
      "cells": [
        "anil",
        "admin123"
      ],
      "line": 15,
      "id": "orangehrm-website;validate-the-login;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 13,
  "name": "validate the login",
  "description": "",
  "id": "orangehrm-website;validate-the-login;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 4,
      "name": "@tc_00_login"
    },
    {
      "line": 1,
      "name": "@orangeHRM"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "I launched the browser",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "I enters the \"Admin\" and \"admin123\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I click login",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I am on the homePage",
  "keyword": "Then "
});
formatter.match({
  "location": "orangehrmloginstep.i_launched_the_browser()"
});
formatter.result({
  "duration": 12219992400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Admin",
      "offset": 14
    },
    {
      "val": "admin123",
      "offset": 26
    }
  ],
  "location": "orangehrmloginstep.i_enters_the_and(String,String)"
});
formatter.result({
  "duration": 1224648800,
  "status": "passed"
});
formatter.match({
  "location": "orangehrmloginstep.i_click_login()"
});
formatter.result({
  "duration": 2293458100,
  "status": "passed"
});
formatter.match({
  "location": "orangehrmloginstep.i_am_on_the_homePage()"
});
formatter.result({
  "duration": 3913786100,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "validate the login",
  "description": "",
  "id": "orangehrm-website;validate-the-login;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 4,
      "name": "@tc_00_login"
    },
    {
      "line": 1,
      "name": "@orangeHRM"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "I launched the browser",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "I enters the \"admin\" and \"Admin124\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I click login",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I am on the homePage",
  "keyword": "Then "
});
formatter.match({
  "location": "orangehrmloginstep.i_launched_the_browser()"
});
formatter.result({
  "duration": 7524870900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "admin",
      "offset": 14
    },
    {
      "val": "Admin124",
      "offset": 26
    }
  ],
  "location": "orangehrmloginstep.i_enters_the_and(String,String)"
});
formatter.result({
  "duration": 1232230000,
  "status": "passed"
});
formatter.match({
  "location": "orangehrmloginstep.i_click_login()"
});
formatter.result({
  "duration": 1587541800,
  "status": "passed"
});
formatter.match({
  "location": "orangehrmloginstep.i_am_on_the_homePage()"
});
formatter.result({
  "duration": 1866411700,
  "status": "passed"
});
formatter.scenario({
  "line": 15,
  "name": "validate the login",
  "description": "",
  "id": "orangehrm-website;validate-the-login;;4",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 4,
      "name": "@tc_00_login"
    },
    {
      "line": 1,
      "name": "@orangeHRM"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "I launched the browser",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "I enters the \"anil\" and \"admin123\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I click login",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I am on the homePage",
  "keyword": "Then "
});
formatter.match({
  "location": "orangehrmloginstep.i_launched_the_browser()"
});
formatter.result({
  "duration": 8043129800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "anil",
      "offset": 14
    },
    {
      "val": "admin123",
      "offset": 25
    }
  ],
  "location": "orangehrmloginstep.i_enters_the_and(String,String)"
});
formatter.result({
  "duration": 663308500,
  "status": "passed"
});
formatter.match({
  "location": "orangehrmloginstep.i_click_login()"
});
formatter.result({
  "duration": 1315923300,
  "status": "passed"
});
formatter.match({
  "location": "orangehrmloginstep.i_am_on_the_homePage()"
});
formatter.result({
  "duration": 1180117100,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 18,
  "name": "validating the click functionality of Directory tab",
  "description": "",
  "id": "orangehrm-website;validating-the-click-functionality-of-directory-tab",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 17,
      "name": "@tc_02_functionality_of_directory_tab"
    }
  ]
});
formatter.step({
  "line": 19,
  "name": "i logged on to the OrangeHRM Home Page and navigate to the Directory Tab",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "i  enterd into directory tab by clicked on it \"\u003cemail1\u003e\" and \"\u003cpass1\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "search directory is displayed",
  "keyword": "Then "
});
formatter.step({
  "line": 22,
  "name": "directory tab is validated successfully",
  "keyword": "And "
});
formatter.examples({
  "line": 24,
  "name": "",
  "description": "",
  "id": "orangehrm-website;validating-the-click-functionality-of-directory-tab;",
  "rows": [
    {
      "cells": [
        "email1",
        "pass1"
      ],
      "line": 25,
      "id": "orangehrm-website;validating-the-click-functionality-of-directory-tab;;1"
    },
    {
      "cells": [
        "Admin",
        "admin123"
      ],
      "line": 26,
      "id": "orangehrm-website;validating-the-click-functionality-of-directory-tab;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 26,
  "name": "validating the click functionality of Directory tab",
  "description": "",
  "id": "orangehrm-website;validating-the-click-functionality-of-directory-tab;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 17,
      "name": "@tc_02_functionality_of_directory_tab"
    },
    {
      "line": 1,
      "name": "@orangeHRM"
    }
  ]
});
formatter.step({
  "line": 19,
  "name": "i logged on to the OrangeHRM Home Page and navigate to the Directory Tab",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "i  enterd into directory tab by clicked on it \"Admin\" and \"admin123\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "search directory is displayed",
  "keyword": "Then "
});
formatter.step({
  "line": 22,
  "name": "directory tab is validated successfully",
  "keyword": "And "
});
formatter.match({
  "location": "Directorystep.i_logged_on_to_the_OrangeHRM_Home_Page_and_navigate_to_the_Directory_Tab()"
});
formatter.result({
  "duration": 7996907400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Admin",
      "offset": 47
    },
    {
      "val": "admin123",
      "offset": 59
    }
  ],
  "location": "Directorystep.i_enterd_into_directory_tab_by_clicked_on_it_and(String,String)"
});
formatter.result({
  "duration": 2684322300,
  "status": "passed"
});
formatter.match({
  "location": "Directorystep.search_directory_is_displayed()"
});
formatter.result({
  "duration": 3886669900,
  "status": "passed"
});
formatter.match({
  "location": "Directorystep.directory_tab_is_validated_successfully()"
});
formatter.result({
  "duration": 3331019800,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 28,
  "name": "validating the search functionality in directory tab",
  "description": "",
  "id": "orangehrm-website;validating-the-search-functionality-in-directory-tab",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 27,
      "name": "@tc_03_validate_search_in_directory_tab"
    }
  ]
});
formatter.step({
  "line": 29,
  "name": "search directory is displayed inside the Directory Tab",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "i entered values to validate search directory \"\u003cemail2\u003e\" and \"\u003cpass2\u003e\" ,\"\u003cemp_name\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "i clicked on the search button",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "the result is dispalyed",
  "keyword": "And "
});
formatter.examples({
  "line": 34,
  "name": "",
  "description": "",
  "id": "orangehrm-website;validating-the-search-functionality-in-directory-tab;",
  "rows": [
    {
      "cells": [
        "email2",
        "pass2",
        "emp_name"
      ],
      "line": 35,
      "id": "orangehrm-website;validating-the-search-functionality-in-directory-tab;;1"
    },
    {
      "cells": [
        "Admin",
        "admin123",
        "Linda Anderson"
      ],
      "line": 36,
      "id": "orangehrm-website;validating-the-search-functionality-in-directory-tab;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 36,
  "name": "validating the search functionality in directory tab",
  "description": "",
  "id": "orangehrm-website;validating-the-search-functionality-in-directory-tab;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 27,
      "name": "@tc_03_validate_search_in_directory_tab"
    },
    {
      "line": 1,
      "name": "@orangeHRM"
    }
  ]
});
formatter.step({
  "line": 29,
  "name": "search directory is displayed inside the Directory Tab",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "i entered values to validate search directory \"Admin\" and \"admin123\" ,\"Linda Anderson\"",
  "matchedColumns": [
    0,
    1,
    2
  ],
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "i clicked on the search button",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "the result is dispalyed",
  "keyword": "And "
});
formatter.match({
  "location": "validsearchstep.search_directory_is_displayed_inside_the_Directory_Tab()"
});
formatter.result({
  "duration": 9275296600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Admin",
      "offset": 47
    },
    {
      "val": "admin123",
      "offset": 59
    },
    {
      "val": "Linda Anderson",
      "offset": 71
    }
  ],
  "location": "validsearchstep.i_entered_values_to_validate_search_directory_and(String,String,String)"
});
formatter.result({
  "duration": 9458780800,
  "status": "passed"
});
formatter.match({
  "location": "validsearchstep.i_clicked_on_the_search_button()"
});
formatter.result({
  "duration": 1122084000,
  "status": "passed"
});
formatter.match({
  "location": "validsearchstep.the_result_is_dispalyed()"
});
formatter.result({
  "duration": 1455376000,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 39,
  "name": "requesting addons to the marketplace",
  "description": "",
  "id": "orangehrm-website;requesting-addons-to-the-marketplace",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 38,
      "name": "@tc_04_requesting_addons_in_marketplace"
    }
  ]
});
formatter.step({
  "line": 40,
  "name": "i logged on to the OrangeHRM Home Page and navigate to the marketplace Tab",
  "keyword": "Given "
});
formatter.step({
  "line": 41,
  "name": "orangehrm addons tab is displayed with multiple addons \"\u003cemail3\u003e\" and \"\u003cpass3\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 42,
  "name": "then i clicked on the request button for adding ldpa",
  "keyword": "Then "
});
formatter.step({
  "line": 43,
  "name": "enter the data to be added on addons",
  "keyword": "And "
});
formatter.step({
  "line": 44,
  "name": "click on ok",
  "keyword": "Then "
});
formatter.examples({
  "line": 46,
  "name": "",
  "description": "",
  "id": "orangehrm-website;requesting-addons-to-the-marketplace;",
  "rows": [
    {
      "cells": [
        "email3",
        "pass3"
      ],
      "line": 47,
      "id": "orangehrm-website;requesting-addons-to-the-marketplace;;1"
    },
    {
      "cells": [
        "Admin",
        "admin123"
      ],
      "line": 48,
      "id": "orangehrm-website;requesting-addons-to-the-marketplace;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 48,
  "name": "requesting addons to the marketplace",
  "description": "",
  "id": "orangehrm-website;requesting-addons-to-the-marketplace;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 38,
      "name": "@tc_04_requesting_addons_in_marketplace"
    },
    {
      "line": 1,
      "name": "@orangeHRM"
    }
  ]
});
formatter.step({
  "line": 40,
  "name": "i logged on to the OrangeHRM Home Page and navigate to the marketplace Tab",
  "keyword": "Given "
});
formatter.step({
  "line": 41,
  "name": "orangehrm addons tab is displayed with multiple addons \"Admin\" and \"admin123\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 42,
  "name": "then i clicked on the request button for adding ldpa",
  "keyword": "Then "
});
formatter.step({
  "line": 43,
  "name": "enter the data to be added on addons",
  "keyword": "And "
});
formatter.step({
  "line": 44,
  "name": "click on ok",
  "keyword": "Then "
});
formatter.match({
  "location": "Marketplacestep.i_logged_on_to_the_OrangeHRM_Home_Page_and_navigate_to_the_marketplace_Tab()"
});
formatter.result({
  "duration": 7241775600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Admin",
      "offset": 56
    },
    {
      "val": "admin123",
      "offset": 68
    }
  ],
  "location": "Marketplacestep.orangehrm_addons_tab_is_displayed_with_multiple_addons_and(String,String)"
});
formatter.result({
  "duration": 2763427300,
  "status": "passed"
});
formatter.match({
  "location": "Marketplacestep.then_i_clicked_on_the_request_button_for_adding_ldpa()"
});
formatter.result({
  "duration": 7193801900,
  "status": "passed"
});
formatter.match({
  "location": "Marketplacestep.enter_the_data_to_be_added_on_addons()"
});
formatter.result({
  "duration": 2336181900,
  "status": "passed"
});
formatter.match({
  "location": "Marketplacestep.click_on_ok()"
});
formatter.result({
  "duration": 1691179600,
  "status": "passed"
});
formatter.uri("nikki_orangehrm.feature");
formatter.feature({
  "line": 3,
  "name": "OrangeHRM Website",
  "description": "",
  "id": "orangehrm-website",
  "keyword": "Feature",
  "tags": [
    {
      "line": 2,
      "name": "@orangehrm"
    }
  ]
});
formatter.scenario({
  "line": 6,
  "name": "Log in to OrangeHRM with valid Credentials",
  "description": "",
  "id": "orangehrm-website;log-in-to-orangehrm-with-valid-credentials",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 5,
      "name": "@tc_01"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "open the url in a browser",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "enter the email id and password in the excel sheet to register click login and assert",
  "keyword": "When "
});
formatter.match({
  "location": "Loginstepdefinition.open_the_url_in_a_browser()"
});
formatter.result({
  "duration": 8538677700,
  "status": "passed"
});
formatter.match({
  "location": "Loginstepdefinition.enter_the_email_id_and_password_in_the_excel_sheet_to_register_click_login_and_assert()"
});
formatter.result({
  "duration": 8416116800,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "adding user details in admin page",
  "description": "",
  "id": "orangehrm-website;adding-user-details-in-admin-page",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 11,
      "name": "@tc_02"
    }
  ]
});
formatter.step({
  "line": 14,
  "name": "user launch the chrome browser2",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "User open the orange hrm login page2",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "login with valid details1",
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "user is able to add the new user in the admin page",
  "keyword": "Then "
});
formatter.match({
  "location": "adding_detailsSD.user_launch_the_chrome_browser2()"
});
formatter.result({
  "duration": 4880380600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "2",
      "offset": 35
    }
  ],
  "location": "adding_detailsSD.user_open_the_orange_hrm_login_page(int)"
});
formatter.result({
  "duration": 4091946400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 24
    }
  ],
  "location": "adding_detailsSD.login_with_valid_details(int)"
});
formatter.result({
  "duration": 5516225400,
  "status": "passed"
});
formatter.match({
  "location": "adding_detailsSD.user_is_able_to_add_the_new_user_in_the_admin_page()"
});
formatter.result({
  "duration": 9244099900,
  "status": "passed"
});
formatter.scenario({
  "line": 20,
  "name": "delete user details in admin page",
  "description": "",
  "id": "orangehrm-website;delete-user-details-in-admin-page",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 19,
      "name": "@tc_03"
    }
  ]
});
formatter.step({
  "line": 22,
  "name": "user launch the chrome browser3",
  "keyword": "Given "
});
formatter.step({
  "line": 23,
  "name": "user open the orange hrm login page3",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "login with required details2",
  "keyword": "Then "
});
formatter.step({
  "line": 25,
  "name": "click on the delete button",
  "keyword": "Then "
});
formatter.match({
  "location": "delete_detailsSD.user_launch_the_chrome_browser3()"
});
formatter.result({
  "duration": 5549642100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "3",
      "offset": 35
    }
  ],
  "location": "delete_detailsSD.user_open_the_orange_hrm_login_page(int)"
});
formatter.result({
  "duration": 4472731100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "2",
      "offset": 27
    }
  ],
  "location": "delete_detailsSD.login_with_required_details(int)"
});
formatter.result({
  "duration": 3477393400,
  "status": "passed"
});
formatter.match({
  "location": "delete_detailsSD.user_is_able_to_delet_the_admin_in_the_admin_page()"
});
formatter.result({
  "duration": 6793328000,
  "status": "passed"
});
formatter.scenario({
  "line": 28,
  "name": "about orange HRM",
  "description": "",
  "id": "orangehrm-website;about-orange-hrm",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 27,
      "name": "@tc_04"
    }
  ]
});
formatter.step({
  "line": 30,
  "name": "user launch the chrome browser4",
  "keyword": "Given "
});
formatter.step({
  "line": 31,
  "name": "login with valid details",
  "keyword": "When "
});
formatter.step({
  "line": 32,
  "name": "user is able to know about orange hrm application",
  "keyword": "Then "
});
formatter.step({
  "line": 33,
  "name": "take the screenshot of about page",
  "keyword": "Then "
});
formatter.match({
  "location": "aboutSD.launcing_the_application_via_chrome_browser()"
});
formatter.result({
  "duration": 9414986700,
  "status": "passed"
});
formatter.match({
  "location": "aboutSD.login_with_valid_details()"
});
formatter.result({
  "duration": 3667700200,
  "status": "passed"
});
formatter.match({
  "location": "aboutSD.user_is_able_to_know_about_orange_hrm_application()"
});
formatter.result({
  "duration": 2918930200,
  "status": "passed"
});
formatter.match({
  "location": "aboutSD.take_the_screenshot_of_about_page()"
});
formatter.result({
  "duration": 1328301800,
  "status": "passed"
});
formatter.uri("tEstcase.feature");
formatter.feature({
  "line": 2,
  "name": "orangeHrm website",
  "description": "",
  "id": "orangehrm-website",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@orangeHRM"
    }
  ]
});
formatter.scenarioOutline({
  "line": 5,
  "name": "validate the login functionality",
  "description": "",
  "id": "orangehrm-website;validate-the-login-functionality",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 4,
      "name": "@tc_00_login"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "I launched OrangeHRM website",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "I enter the \"\u003cusername\u003e\" and \"\u003cpassword\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I click the login button",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I am on Home page",
  "keyword": "Then "
});
formatter.examples({
  "line": 11,
  "name": "",
  "description": "",
  "id": "orangehrm-website;validate-the-login-functionality;",
  "rows": [
    {
      "cells": [
        "username",
        "password"
      ],
      "line": 12,
      "id": "orangehrm-website;validate-the-login-functionality;;1"
    },
    {
      "cells": [
        "Admin",
        "admin123"
      ],
      "line": 13,
      "id": "orangehrm-website;validate-the-login-functionality;;2"
    },
    {
      "cells": [
        "admin",
        "Admin124"
      ],
      "line": 14,
      "id": "orangehrm-website;validate-the-login-functionality;;3"
    },
    {
      "cells": [
        "harsha",
        "admin123"
      ],
      "line": 15,
      "id": "orangehrm-website;validate-the-login-functionality;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 13,
  "name": "validate the login functionality",
  "description": "",
  "id": "orangehrm-website;validate-the-login-functionality;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 4,
      "name": "@tc_00_login"
    },
    {
      "line": 1,
      "name": "@orangeHRM"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "I launched OrangeHRM website",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "I enter the \"Admin\" and \"admin123\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I click the login button",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I am on Home page",
  "keyword": "Then "
});
formatter.match({
  "location": "DEF_LOGIN.i_launched_OrangeHRM_website()"
});
formatter.result({
  "duration": 11006562500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Admin",
      "offset": 13
    },
    {
      "val": "admin123",
      "offset": 25
    }
  ],
  "location": "DEF_LOGIN.i_enter_the_and(String,String)"
});
formatter.result({
  "duration": 2068801100,
  "status": "passed"
});
formatter.match({
  "location": "DEF_LOGIN.i_click_the_login_button()"
});
formatter.result({
  "duration": 2807221600,
  "status": "passed"
});
formatter.match({
  "location": "DEF_LOGIN.i_am_on_Home_page()"
});
formatter.result({
  "duration": 7453428800,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "validate the login functionality",
  "description": "",
  "id": "orangehrm-website;validate-the-login-functionality;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 4,
      "name": "@tc_00_login"
    },
    {
      "line": 1,
      "name": "@orangeHRM"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "I launched OrangeHRM website",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "I enter the \"admin\" and \"Admin124\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I click the login button",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I am on Home page",
  "keyword": "Then "
});
formatter.match({
  "location": "DEF_LOGIN.i_launched_OrangeHRM_website()"
});
formatter.result({
  "duration": 10301745400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "admin",
      "offset": 13
    },
    {
      "val": "Admin124",
      "offset": 25
    }
  ],
  "location": "DEF_LOGIN.i_enter_the_and(String,String)"
});
formatter.result({
  "duration": 1845545200,
  "status": "passed"
});
formatter.match({
  "location": "DEF_LOGIN.i_click_the_login_button()"
});
formatter.result({
  "duration": 2648022000,
  "status": "passed"
});
formatter.match({
  "location": "DEF_LOGIN.i_am_on_Home_page()"
});
formatter.result({
  "duration": 3189040200,
  "status": "passed"
});
formatter.scenario({
  "line": 15,
  "name": "validate the login functionality",
  "description": "",
  "id": "orangehrm-website;validate-the-login-functionality;;4",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 4,
      "name": "@tc_00_login"
    },
    {
      "line": 1,
      "name": "@orangeHRM"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "I launched OrangeHRM website",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "I enter the \"harsha\" and \"admin123\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "I click the login button",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "I am on Home page",
  "keyword": "Then "
});
formatter.match({
  "location": "DEF_LOGIN.i_launched_OrangeHRM_website()"
});
formatter.result({
  "duration": 8605430800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "harsha",
      "offset": 13
    },
    {
      "val": "admin123",
      "offset": 26
    }
  ],
  "location": "DEF_LOGIN.i_enter_the_and(String,String)"
});
formatter.result({
  "duration": 1859007000,
  "status": "passed"
});
formatter.match({
  "location": "DEF_LOGIN.i_click_the_login_button()"
});
formatter.result({
  "duration": 1432410700,
  "status": "passed"
});
formatter.match({
  "location": "DEF_LOGIN.i_am_on_Home_page()"
});
formatter.result({
  "duration": 3676580700,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Logout",
  "description": "",
  "id": "orangehrm-website;logout",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 17,
      "name": "@tc_00_logout"
    }
  ]
});
formatter.step({
  "line": 19,
  "name": "I am logged in on the site",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "I click the Log out button",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "I go back to my login page",
  "keyword": "Then "
});
formatter.match({
  "location": "DEF_LOGOUT.i_am_logged_in_on_the_site()"
});
formatter.result({
  "duration": 10250576800,
  "status": "passed"
});
formatter.match({
  "location": "DEF_LOGOUT.i_click_the_Log_out_button()"
});
formatter.result({
  "duration": 6848456600,
  "status": "passed"
});
formatter.match({
  "location": "DEF_LOGOUT.i_go_back_to_my_login_page()"
});
formatter.result({
  "duration": 1119858100,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 24,
  "name": "ADD PIM Report",
  "description": "",
  "id": "orangehrm-website;add-pim-report",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 23,
      "name": "@tc_01_ADD_PIM_Report"
    }
  ]
});
formatter.step({
  "line": 25,
  "name": "I Logged in to the website using",
  "keyword": "Given "
});
formatter.step({
  "line": 26,
  "name": "I click on PIM \"\u003cusername1\u003e\" and \"\u003cpassword1\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "I click on Report",
  "keyword": "Then "
});
formatter.step({
  "line": 28,
  "name": "I click on ADD report",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "I enter the details of the report \"\u003creportname\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "I click save",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "I find Report Successfully added \"\u003creportname1\u003e\"",
  "keyword": "Then "
});
formatter.examples({
  "line": 33,
  "name": "",
  "description": "",
  "id": "orangehrm-website;add-pim-report;",
  "rows": [
    {
      "cells": [
        "username1",
        "password1",
        "reportname",
        "reportname1"
      ],
      "line": 34,
      "id": "orangehrm-website;add-pim-report;;1"
    },
    {
      "cells": [
        "Admin",
        "admin123",
        "PIM report",
        "PIM report"
      ],
      "line": 35,
      "id": "orangehrm-website;add-pim-report;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 35,
  "name": "ADD PIM Report",
  "description": "",
  "id": "orangehrm-website;add-pim-report;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 23,
      "name": "@tc_01_ADD_PIM_Report"
    },
    {
      "line": 1,
      "name": "@orangeHRM"
    }
  ]
});
formatter.step({
  "line": 25,
  "name": "I Logged in to the website using",
  "keyword": "Given "
});
formatter.step({
  "line": 26,
  "name": "I click on PIM \"Admin\" and \"admin123\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "I click on Report",
  "keyword": "Then "
});
formatter.step({
  "line": 28,
  "name": "I click on ADD report",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "I enter the details of the report \"PIM report\"",
  "matchedColumns": [
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "I click save",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "I find Report Successfully added \"PIM report\"",
  "matchedColumns": [
    3
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "DEF_PIM.i_Logged_in_to_the_website_using()"
});
formatter.result({
  "duration": 8885703500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Admin",
      "offset": 16
    },
    {
      "val": "admin123",
      "offset": 28
    }
  ],
  "location": "DEF_PIM.i_click_on_PIM_and(String,String)"
});
formatter.result({
  "duration": 8557087300,
  "status": "passed"
});
formatter.match({
  "location": "DEF_PIM.i_click_on_Report()"
});
formatter.result({
  "duration": 1151805200,
  "status": "passed"
});
formatter.match({
  "location": "DEF_PIM.i_click_on_ADD_report()"
});
formatter.result({
  "duration": 2142441600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "PIM report",
      "offset": 35
    }
  ],
  "location": "DEF_PIM.i_enter_the_details_of_the_report(String)"
});
formatter.result({
  "duration": 1242392100,
  "status": "passed"
});
formatter.match({
  "location": "DEF_PIM.i_click_save()"
});
formatter.result({
  "duration": 1909269800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "PIM report",
      "offset": 34
    }
  ],
  "location": "DEF_PIM.i_find_Report_Successfully_added(String)"
});
formatter.result({
  "duration": 4574683600,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 38,
  "name": "delete PIM Report",
  "description": "",
  "id": "orangehrm-website;delete-pim-report",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 37,
      "name": "@tc_02_delete_PIM_Report"
    }
  ]
});
formatter.step({
  "line": 39,
  "name": "I have Log in to the website",
  "keyword": "Given "
});
formatter.step({
  "line": 40,
  "name": "I clicked on PIM  \"\u003cusername2\u003e\" and \"\u003cpassword2\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 41,
  "name": "I clicked on Report",
  "keyword": "Then "
});
formatter.step({
  "line": 42,
  "name": "I select a project \"\u003creportname2\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 43,
  "name": "I click delete button",
  "keyword": "And "
});
formatter.step({
  "line": 44,
  "name": "I find report successfully deleted \"\u003cdelrpt\u003e\"",
  "keyword": "Then "
});
formatter.examples({
  "line": 46,
  "name": "",
  "description": "",
  "id": "orangehrm-website;delete-pim-report;",
  "rows": [
    {
      "cells": [
        "username2",
        "password2",
        "reportname2",
        "delrpt"
      ],
      "line": 47,
      "id": "orangehrm-website;delete-pim-report;;1"
    },
    {
      "cells": [
        "Admin",
        "admin123",
        "PIM report",
        "PIM report"
      ],
      "line": 48,
      "id": "orangehrm-website;delete-pim-report;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 48,
  "name": "delete PIM Report",
  "description": "",
  "id": "orangehrm-website;delete-pim-report;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 37,
      "name": "@tc_02_delete_PIM_Report"
    },
    {
      "line": 1,
      "name": "@orangeHRM"
    }
  ]
});
formatter.step({
  "line": 39,
  "name": "I have Log in to the website",
  "keyword": "Given "
});
formatter.step({
  "line": 40,
  "name": "I clicked on PIM  \"Admin\" and \"admin123\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 41,
  "name": "I clicked on Report",
  "keyword": "Then "
});
formatter.step({
  "line": 42,
  "name": "I select a project \"PIM report\"",
  "matchedColumns": [
    2
  ],
  "keyword": "When "
});
formatter.step({
  "line": 43,
  "name": "I click delete button",
  "keyword": "And "
});
formatter.step({
  "line": 44,
  "name": "I find report successfully deleted \"PIM report\"",
  "matchedColumns": [
    3
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "DEF_PIM_DEL.i_have_Log_in_to_the_website()"
});
formatter.result({
  "duration": 8245928200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Admin",
      "offset": 19
    },
    {
      "val": "admin123",
      "offset": 31
    }
  ],
  "location": "DEF_PIM_DEL.i_clicked_on_PIM_and(String,String)"
});
formatter.result({
  "duration": 7648782000,
  "status": "passed"
});
formatter.match({
  "location": "DEF_PIM_DEL.i_clicked_on_Report()"
});
formatter.result({
  "duration": 1213688800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "PIM report",
      "offset": 20
    }
  ],
  "location": "DEF_PIM_DEL.i_select_a_project(String)"
});
formatter.result({
  "duration": 2400189800,
  "status": "passed"
});
formatter.match({
  "location": "DEF_PIM_DEL.i_click_delete_button()"
});
formatter.result({
  "duration": 1906669400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "PIM report",
      "offset": 36
    }
  ],
  "location": "DEF_PIM_DEL.i_find_report_successfully_deleted(String)"
});
formatter.result({
  "duration": 4353509800,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 51,
  "name": "Assign leave",
  "description": "",
  "id": "orangehrm-website;assign-leave",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 50,
      "name": "@tc_03_Assign_Leave_and_Search_for_assigned_leave"
    }
  ]
});
formatter.step({
  "line": 52,
  "name": "I have Log in to the website",
  "keyword": "Given "
});
formatter.step({
  "line": 53,
  "name": "I click on Leave \"\u003cusername3\u003e\" and \"\u003cpassword3\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 54,
  "name": "I click on Assign Leave",
  "keyword": "Then "
});
formatter.step({
  "line": 55,
  "name": "I enter the details \"\u003cEmployeename\u003e\" \"\u003cleavetype\u003e\" \"\u003cfromdate\u003e\" \"\u003cTodate\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 56,
  "name": "I click Save button",
  "keyword": "When "
});
formatter.step({
  "line": 57,
  "name": "I find the of employee leave in leave report \"\u003cEmployeename\u003e\" ,\"\u003cfromdate\u003e\", \"\u003cTodate\u003e\"",
  "keyword": "Then "
});
formatter.examples({
  "line": 59,
  "name": "",
  "description": "",
  "id": "orangehrm-website;assign-leave;",
  "rows": [
    {
      "cells": [
        "username3",
        "password3",
        "Employeename",
        "leavetype",
        "fromdate",
        "Todate"
      ],
      "line": 60,
      "id": "orangehrm-website;assign-leave;;1"
    },
    {
      "cells": [
        "Admin",
        "admin123",
        "Linda Anderson",
        "Vacation US",
        "2020-04-15",
        "2020-04-15"
      ],
      "line": 61,
      "id": "orangehrm-website;assign-leave;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 61,
  "name": "Assign leave",
  "description": "",
  "id": "orangehrm-website;assign-leave;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 50,
      "name": "@tc_03_Assign_Leave_and_Search_for_assigned_leave"
    },
    {
      "line": 1,
      "name": "@orangeHRM"
    }
  ]
});
formatter.step({
  "line": 52,
  "name": "I have Log in to the website",
  "keyword": "Given "
});
formatter.step({
  "line": 53,
  "name": "I click on Leave \"Admin\" and \"admin123\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 54,
  "name": "I click on Assign Leave",
  "keyword": "Then "
});
formatter.step({
  "line": 55,
  "name": "I enter the details \"Linda Anderson\" \"Vacation US\" \"2020-04-15\" \"2020-04-15\"",
  "matchedColumns": [
    2,
    3,
    4,
    5
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 56,
  "name": "I click Save button",
  "keyword": "When "
});
formatter.step({
  "line": 57,
  "name": "I find the of employee leave in leave report \"Linda Anderson\" ,\"2020-04-15\", \"2020-04-15\"",
  "matchedColumns": [
    2,
    4,
    5
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "DEF_PIM_DEL.i_have_Log_in_to_the_website()"
});
formatter.result({
  "duration": 7083178000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Admin",
      "offset": 18
    },
    {
      "val": "admin123",
      "offset": 30
    }
  ],
  "location": "DEF_LEAVE.i_click_on_Leave_and(String,String)"
});
formatter.result({
  "duration": 3291327400,
  "status": "passed"
});
formatter.match({
  "location": "DEF_LEAVE.i_click_on_Assign_Leave()"
});
formatter.result({
  "duration": 6420826300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Linda Anderson",
      "offset": 21
    },
    {
      "val": "Vacation US",
      "offset": 38
    },
    {
      "val": "2020-04-15",
      "offset": 52
    },
    {
      "val": "2020-04-15",
      "offset": 65
    }
  ],
  "location": "DEF_LEAVE.i_enter_the_details(String,String,String,String)"
});
formatter.result({
  "duration": 3996532500,
  "status": "passed"
});
formatter.match({
  "location": "DEF_LEAVE.i_click_Save_button()"
});
formatter.result({
  "duration": 416285300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Linda Anderson",
      "offset": 46
    },
    {
      "val": "2020-04-15",
      "offset": 64
    },
    {
      "val": "2020-04-15",
      "offset": 78
    }
  ],
  "location": "DEF_LEAVE.i_find_the_of_employee_leave_in_leave_report(String,String,String)"
});
formatter.result({
  "duration": 7054046800,
  "status": "passed"
});
formatter.scenarioOutline({
  "line": 64,
  "name": "Edit organisation name",
  "description": "",
  "id": "orangehrm-website;edit-organisation-name",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 63,
      "name": "@tc_04_Edit_organisation_name_and_verify_the_changes"
    }
  ]
});
formatter.step({
  "line": 65,
  "name": "I have Log in to the website",
  "keyword": "Given "
});
formatter.step({
  "line": 66,
  "name": "I clicked Admin \"\u003cusername4\u003e\" and \"\u003cpassword4\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 67,
  "name": "I clicked organisation",
  "keyword": "Then "
});
formatter.step({
  "line": 68,
  "name": "I clicked General Info",
  "keyword": "Then "
});
formatter.step({
  "line": 69,
  "name": "I Clicked edit",
  "keyword": "And "
});
formatter.step({
  "line": 70,
  "name": "I change the organisation name \"\u003corganisationname\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 71,
  "name": "I click save button",
  "keyword": "And "
});
formatter.step({
  "line": 72,
  "name": "I find the organisation name successfully changed",
  "keyword": "Then "
});
formatter.examples({
  "line": 74,
  "name": "",
  "description": "",
  "id": "orangehrm-website;edit-organisation-name;",
  "rows": [
    {
      "cells": [
        "username4",
        "password4",
        "organisationname"
      ],
      "line": 75,
      "id": "orangehrm-website;edit-organisation-name;;1"
    },
    {
      "cells": [
        "Admin",
        "admin123",
        "Harsha Solutions"
      ],
      "line": 76,
      "id": "orangehrm-website;edit-organisation-name;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 76,
  "name": "Edit organisation name",
  "description": "",
  "id": "orangehrm-website;edit-organisation-name;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 63,
      "name": "@tc_04_Edit_organisation_name_and_verify_the_changes"
    },
    {
      "line": 1,
      "name": "@orangeHRM"
    }
  ]
});
formatter.step({
  "line": 65,
  "name": "I have Log in to the website",
  "keyword": "Given "
});
formatter.step({
  "line": 66,
  "name": "I clicked Admin \"Admin\" and \"admin123\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 67,
  "name": "I clicked organisation",
  "keyword": "Then "
});
formatter.step({
  "line": 68,
  "name": "I clicked General Info",
  "keyword": "Then "
});
formatter.step({
  "line": 69,
  "name": "I Clicked edit",
  "keyword": "And "
});
formatter.step({
  "line": 70,
  "name": "I change the organisation name \"Harsha Solutions\"",
  "matchedColumns": [
    2
  ],
  "keyword": "When "
});
formatter.step({
  "line": 71,
  "name": "I click save button",
  "keyword": "And "
});
formatter.step({
  "line": 72,
  "name": "I find the organisation name successfully changed",
  "keyword": "Then "
});
formatter.match({
  "location": "DEF_PIM_DEL.i_have_Log_in_to_the_website()"
});
formatter.result({
  "duration": 7481147500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Admin",
      "offset": 17
    },
    {
      "val": "admin123",
      "offset": 29
    }
  ],
  "location": "DEF_ADMIN.i_clicked_Admin_and(String,String)"
});
formatter.result({
  "duration": 9570327500,
  "status": "passed"
});
formatter.match({
  "location": "DEF_ADMIN.i_clicked_organisation()"
});
formatter.result({
  "duration": 473328500,
  "status": "passed"
});
formatter.match({
  "location": "DEF_ADMIN.i_clicked_General_Info()"
});
formatter.result({
  "duration": 1348124300,
  "status": "passed"
});
formatter.match({
  "location": "DEF_ADMIN.i_Clicked_edit()"
});
formatter.result({
  "duration": 445640600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Harsha Solutions",
      "offset": 32
    }
  ],
  "location": "DEF_ADMIN.i_change_the_organisation_name(String)"
});
formatter.result({
  "duration": 1454917900,
  "status": "passed"
});
formatter.match({
  "location": "DEF_ADMIN.i_click_save_button()"
});
formatter.result({
  "duration": 1450363500,
  "status": "passed"
});
formatter.match({
  "location": "DEF_ADMIN.i_find_the_organisation_name_successfully_changed()"
});
formatter.result({
  "duration": 1905614600,
  "status": "passed"
});
});